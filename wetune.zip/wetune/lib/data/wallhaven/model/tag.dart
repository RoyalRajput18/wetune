class Tag {
  final String? id;
  final String? name;
  final String? alias;
  final String? categoryId;
  final String? category;
  Tag({
    this.id,
    this.name,
    this.alias,
    this.categoryId,
    this.category,
  });
}
