String pexelApiKey = "563492ad6f91700001000001ddb30ed897fb4e43a7f423095a92abda";
String fcmServerToken =
    "AAAA1uNHrnc:APA91bFv3dZwCW18tJCa_vXnTtsbyOS-Hz6ar13OhHCIWpPglMNAZ-gVAoGpQ8RBBvTbMkmy7qF7uBnqoV3_N1PPWcVruAkZNr8HhlCTrL0gONRHrQ_s0io-XG0GthGFd1bI_U75Vx6B";
const String token = 'github-personal-access-token';
const String gitUserName = 'github-username';
const String repoName = 'wallpapers-repository-name';
const String repoName2 = 'setups-repository-name';
const String repoName3 = 'views-repository-name';
const String apiKey = 'revenuecat-payments-api-key';
const String user1Image1 = "";
const String user1Image2 = "";
const String user1Image3 = "";
const String user2Image1 = "";
const String user2Image2 = "";
const String user2Image3 = "";
const String user3Image1 = "";
const String user3Image2 = "";
const String user3Image3 = "";
