import 'package:flutter/material.dart';

class SearchProviderMenuItem {
  String? title;
  IconData? icon;
  SearchProviderMenuItem({this.title, this.icon});
}
