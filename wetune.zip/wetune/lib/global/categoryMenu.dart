class CategoryMenu {
  String? name;
  String? provider;
  String? image;
  CategoryMenu({this.name, this.provider, this.image});
}
